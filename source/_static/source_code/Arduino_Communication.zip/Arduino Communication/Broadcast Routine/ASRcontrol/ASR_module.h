#ifndef __ASR_MODULE_H
#define __ASR_MODULE_H

#include <Wire.h>

#define I2C_ADDR		0x34
//Recognition result storage address. By continuously reading the value at this address, you can determine if speech has been recognized. Different values correspond to different recognized speech.
#define ASR_RESULT_ADDR   100
#define ASR_SPEAK_ADDR    110

#define ASR_CMDMAND    0x00
#define ASR_ANNOUNCER  0xFF

class ASR_MOUDLE
{
  public:
    ASR_MOUDLE(void);
    uint8_t rec_recognition(void);
    void speak(uint8_t cmd , uint8_t id);

  private:
    uint8_t send[2];
};

#endif //__ASR_MODULE_H

