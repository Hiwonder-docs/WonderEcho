#!/usr/bin/python3
# coding=utf8
import smbus
import time

# I2C address
I2C_ADDR = 0x34  # I2C address
ASR_RESULT_ADDR = 100  # ASR result register address
ASR_SPEAK_ADDR = 110  # ASR speaking register address
ASR_CMDMAND = 0x00
ASR_ANNOUNCER = 0xFF

class ASRModule:
    def __init__(self,address, bus=1):
        # Initialize I2C bus and device address
        self.bus = smbus.SMBus(bus)  # Use I2C bus 1
        self.address = address  # Device's I2C address
        self.send = [0, 0]  # Initialize the data array to be sent

    def wire_write_byte(self, val):
        """
        Write a single byte to the device
        :param val: The byte value to be written
        :return: True if written successfully, False if failed
        """
        try:
            self.bus.write_byte(self.address, val) # Send the byte to the device
            return True # Write successful
        except IOError:
            return False # Write failed, return False

    def wire_write_data_array(self, reg, val, length):
        """
        Write a byte array to the specified register
        :param reg: Register address
        :param val: Byte array to be written
        :param length: Number of bytes to write
        :return: True if the write is successful, False otherwise
        """
        try:            
            self.bus.write_i2c_block_data(self.address, reg, val[:length]) # 发送字节数组到设备的指定寄存器
            return True # Write successful
        except IOError:
            return False # Write failed, return False

    def wire_read_data_array(self, reg, length):
        """
        Read a byte array from the specified register
        :param reg: Register address
        :param length: Number of bytes to read
        :return: The byte array read; returns an empty array if reading fails
        """          
        try:
            result = self.bus.read_i2c_block_data(self.address, reg, 1) # Read byte array from the device
            return result # Return the result
        except IOError:
            return [] # Reading failed, return an empty array

    def rec_recognition(self):
        """
        Read recognition result
        :return: The recognition result; returns 0 if reading fails
        """
        result = self.wire_read_data_array(ASR_RESULT_ADDR, 1) # Read one byte from the result register
        if result:
            return result # Return the result
        return 0  # Return 0 if no result is obtained

    def speak(self, cmd, id):
        """
        Send a speech command to the device
        :param cmd: Command byte
        :param id: ID of the speech message
        """
        if cmd == ASR_ANNOUNCER or cmd == ASR_CMDMAND: # Check if the command is valid
            self.send[0] = cmd # Set the first element of the send array as the command
            self.send[1] = id # Set the second element of the send array as the ID
            self.wire_write_data_array(ASR_SPEAK_ADDR, self.send, 2) # Send the command and ID to the specified register


if __name__ == "__main__":
    asr_module = ASRModule(I2C_ADDR)    
    while True:
        recognition_result = asr_module.rec_recognition()
        if recognition_result[0] != 0:
            if recognition_result[0] == 1:
                print("go")
            elif recognition_result[0] == 2:
                print("back")
            elif recognition_result[0] == 3:
                print("left")
            elif recognition_result[0] == 4:
                print("right")
            elif recognition_result[0] == 9:
                print("stop")