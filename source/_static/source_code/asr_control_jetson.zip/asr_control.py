#!/usr/bin/python3
# coding=utf8
import smbus
import time

'''
/****************************************************
  Company:   Hiwonder
  Author:Shenzhen Hiwonder Technology Co., Ltd
  Shop:https://www.hiwonder.com/
*****************************************************
  Sensor：Hiwonder Series Speech Recognition Module
  Communication Interface: I2C
  Output Type: Digital Signal
*****************************************************/
'''


I2C_ADDR = 0x34  # I2C address

# The recognition results are stored at this address. Continuously monitoring its value indicates whether speech has been detected, with each value corresponding to a specific voice command.
ASR_RESULT_ADDR = 0x64  
ASR_SPEAK_ADDR = 0x6E

ASR_CMDMAND = 0x00
ASR_ANNOUNCER = 0xFF

class ASRModule:
    def __init__(self,address, bus=1):
        # Initialize the I2C bus and device address
        self.bus = smbus.SMBus(bus)  # Use I2C bus 1
        self.address = address  # I2C address of the device
        self.send = [0, 0]  # Initialize the data array for transmission

    def wire_write_byte(self, val):
        """
        Write a single byte to the device
        :param val: The byte value to write
        :return: True if the write is successful, False otherwise
        """
        try:
            self.bus.write_byte(self.address, val) # Send the byte to the device
            return True # Write successful
        except IOError:
            return False # Write failed, return False

    def wire_write_data_array(self, reg, val, length):
        """
        Write a byte array to the specified register.
        :param reg: The register address
        :param val: The byte array to write
        :param length: The number of bytes to write
        :return: True if the write is successful, False otherwise
        """
        try:            
            self.bus.write_i2c_block_data(self.address, reg, val[:length]) # Send the specified number of bytes to the target register
            return True # Write successful
        except IOError:
            return False # Write failed, return False

    def wire_read_data_array(self, reg, length):
        """
        Read a byte array from the specified register.
        :param reg: The register address
        :param length: The number of bytes to read
        :return: The byte array read from the device, or an empty array if the read fails
        """          
        try:
            result = self.bus.read_i2c_block_data(self.address, reg, 1) # Read byte array from the device
            return result # Return the read result
        except IOError:
            return [] # Return an empty array if the read fails

    def rec_recognition(self):
        """
        Retrieve the recognition result.
        :return: The recognition result, or 0 if the read fails
        """
        result = self.wire_read_data_array(ASR_RESULT_ADDR, 1) # Read one byte from the result register
        if result:
            return result # Return the result if available
        return 0  # Return 0 if no result is available

    def speak(self, cmd, id):
        """
        Send a speech command to the device.
        :param cmd: The command byte
        :param id: The ID of the speech to be played
        """
        if cmd == ASR_ANNOUNCER or cmd == ASR_CMDMAND: # Check if the command is valid
            self.send[0] = cmd # Set the first element of the send array to the command
            self.send[1] = id # Set the second element to the speech ID
            self.wire_write_data_array(ASR_SPEAK_ADDR, self.send, 2) # Send the command and ID to the specified register


if __name__ == "__main__":
    asr_module = ASRModule(I2C_ADDR)    
    # Define the speech content and its corresponding ID
    announcements = [
        (ASR_CMDMAND, 1),  # Moving forward
        (ASR_CMDMAND, 3),  # Turning left
        (ASR_ANNOUNCER, 1),  # Recyclable materials
        (ASR_ANNOUNCER, 3)   # Hazardous waste
    ]
    
    while True:
        for cmd, id in announcements:
            asr_module.speak(cmd, id)
            time.sleep(5) 
        